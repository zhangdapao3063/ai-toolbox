// ================================================================
// 类型定义
// ================================================================

export type ToolCategory =
  | "writing"    // 核心写作
  | "planning"   // 构思规划
  | "character"  // 人设世界观
  | "package"    // 包装推广
  | "video";     // 剧本视频

export interface CategoryDef {
  id: ToolCategory | "all";
  label: string;
  icon: string;
}

export interface Tool {
  id: number;
  category: ToolCategory;
  icon: string;
  name: string;
  tag: "hot" | "new" | "pro" | null;
  tagText: string;
  desc: string;
  detailDesc: string;
  models: string[];
  features: string[];
  accent: string;
  iconBg: string;
  /** 对接 Dify 的 App ID / Workflow ID */
  difyAppId?: string;
  /** 触发该工具时传给 Dify 的 system prompt 片段 */
  systemPrompt?: string;
}

// Dify 流式响应的事件类型（参考 Dify /chat-messages API）
export interface DifyMessage {
  event: "message" | "agent_message" | "message_end" | "message_file" | "error";
  task_id?: string;
  id?: string;
  message_id?: string;
  conversation_id?: string;
  mode?: "chat" | "agent" | "advanced-chat" | "workflow";
  answer?: string;
  created_at?: number;
  error?: string;
}

export interface ChatRequest {
  toolId: number;
  message: string;
  conversationId?: string;
}

export interface ChatResponse {
  answer: string;
  conversationId: string;
}
