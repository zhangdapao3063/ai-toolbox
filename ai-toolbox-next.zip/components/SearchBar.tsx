"use client";

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
}

export default function SearchBar({ value, onChange }: SearchBarProps) {
  return (
    <div className="relative max-w-lg">
      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 text-[17px] pointer-events-none">
        🔍
      </span>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="搜索工具名称或功能描述..."
        className="
          w-full pl-11 pr-10 py-3.5 rounded-xl
          bg-white/4 backdrop-blur-xl border border-white/8
          text-slate-100 text-[15px] placeholder-slate-600
          outline-none
          focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 focus:bg-white/6
          transition-all duration-200
        "
      />
      {value && (
        <button
          onClick={() => onChange("")}
          className="absolute right-3 top-1/2 -translate-y-1/2
                     w-7 h-7 rounded-full flex items-center justify-center
                     text-slate-500 hover:text-slate-200 hover:bg-white/8
                     transition-all duration-150 text-[15px]"
        >
          ✕
        </button>
      )}
    </div>
  );
}
