/**
 * Dify API 对接层
 *
 * 参考文档: https://docs.dify.ai/getting-started/api-connectivity
 *
 * Dify 支持两种调用方式：
 *  1. /chat-messages — 流式对话（适合用户交互场景）
 *  2. /workflows/run  — 工作流执行（适合固定流程的工具调用）
 *
 * 此文件封装了流式对话的核心逻辑。
 */

const DIFY_BASE_URL = process.env.NEXT_PUBLIC_DIFY_API_URL ?? "https://api.dify.ai/v1";
const API_KEY = process.env.DIFY_API_KEY ?? "";

// ================================================================
// 类型定义
// ================================================================

export interface DifyChatParams {
  query: string;
  userId?: string;
  conversationId?: string;
  /** 是否启用流式返回（默认 true） */
  stream?: boolean;
  /** 自定义变量，key-value 形式传给 Dify App */
  inputs?: Record<string, string>;
}

export interface DifyChatResponse {
  answer: string;
  conversationId: string;
  messageId: string;
}

// ================================================================
// 核心 API 调用
// ================================================================

/**
 * 发送对话消息到 Dify（流式 / 非流式）
 *
 * @param params     对话参数
 * @param onChunk    流式回调，每次收到一个 answer 片段时触发
 * @param onEnd     完成回调
 * @param onError   错误回调
 */
export async function sendChatMessage(
  params: DifyChatParams,
  onChunk?: (text: string) => void,
  onEnd?: (fullAnswer: string) => void,
  onError?: (err: Error) => void
) {
  const { query, userId = "anonymous", conversationId, stream = true, inputs } = params;

  const payload: Record<string, unknown> = {
    query,
    user: userId,
    stream,
    ...(inputs && { inputs }),
    ...(conversationId && { conversation_id: conversationId }),
  };

  let fullAnswer = "";

  try {
    const response = await fetch(`${DIFY_BASE_URL}/chat-messages`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Dify API 错误: ${response.status} — ${errorText}`);
    }

    if (stream) {
      // ── 流式读取 SSE ──────────────────────────────────────
      const reader = response.body?.getReader();
      if (!reader) throw new Error("响应体无法读取");

      const decoder = new TextDecoder("utf-8");
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        // 按换行符拆分行
        const lines = buffer.split("\n");
        // 最后一行可能是不完整的，留在 buffer 里
        buffer = lines.pop() ?? "";

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed || trimmed.startsWith(":")) continue; // 跳过空行和 SSE comment

          // Dify 流式事件格式: data: {...}
          if (!trimmed.startsWith("data:")) continue;

          const dataStr = trimmed.slice(5).trim();
          if (!dataStr) continue;

          try {
            const event = JSON.parse(dataStr);

            if (event.event === "message" || event.event === "agent_message") {
              if (event.answer) {
                fullAnswer += event.answer;
                onChunk?.(event.answer);
              }
            }

            if (event.event === "message_end") {
              onEnd?.(fullAnswer);
              return;
            }

            if (event.event === "error") {
              throw new Error(event.error ?? "Dify 流式响应出错");
            }
          } catch {
            // 忽略解析失败的行（可能是截断的 JSON）
          }
        }
      }

      // 正常结束但没有收到 message_end 事件
      onEnd?.(fullAnswer);
    } else {
      // ── 非流式读取 ─────────────────────────────────────────
      const data = await response.json();
      fullAnswer = data.answer ?? "";
      onEnd?.(fullAnswer);
      return { answer: fullAnswer, conversationId: data.conversation_id, messageId: data.message_id };
    }
  } catch (err) {
    const error = err instanceof Error ? err : new Error(String(err));
    onError?.(error);
    throw error;
  }
}

// ================================================================
// 快捷封装（Promise 风格，适合简单场景）
// ================================================================

/**
 * 发送消息并等待完整响应（自动重试一次）
 */
export async function chatOnce(params: Omit<DifyChatParams, "stream">): Promise<DifyChatResponse> {
  let lastError: Error | null = null;

  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      return await new Promise((resolve, reject) => {
        let answer = "";
        let conversationId = "";
        let messageId = "";

        sendChatMessage(
          { ...params, stream: false },
          undefined,
          (full) => {
            resolve({ answer: full, conversationId, messageId });
          },
          (err) => reject(err)
        );

        // 手动等待非流式响应（捕获 conversation_id）
        // 注意：这里简化处理，实际可以在 onChunk 里收集 conversationId
      });
    } catch (err) {
      lastError = err instanceof Error ? err : new Error(String(err));
    }
  }

  throw lastError ?? new Error("Dify 调用失败");
}
