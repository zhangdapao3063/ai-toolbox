"use client";

import type { CategoryDef } from "@/types";

interface FilterTabsProps {
  categories: CategoryDef[];
  active: string;
  onChange: (id: string) => void;
}

export default function FilterTabs({ categories, active, onChange }: FilterTabsProps) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
      {categories.map((cat) => {
        const isActive = cat.id === active;
        return (
          <button
            key={cat.id}
            onClick={() => onChange(cat.id)}
            className={`
              flex-shrink-0 flex items-center gap-1.5 px-5 py-2.5 rounded-full text-[13.5px] font-semibold
              border transition-all duration-150 whitespace-nowrap
              ${isActive
                ? "bg-gradient-to-r from-indigo-500 to-purple-500 text-white border-transparent shadow-glow-sm"
                : "bg-white/4 text-slate-400 border-white/8 hover:border-indigo-500/40 hover:text-slate-100 hover:bg-white/6"
              }
            `}
          >
            <span>{cat.icon}</span>
            <span>{cat.label}</span>
            <span className={`text-[11px] ${isActive ? "opacity-70" : "opacity-50"}`}>
              {cat.count}
            </span>
          </button>
        );
      })}
    </div>
  );
}
