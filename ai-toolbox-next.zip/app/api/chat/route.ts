/**
 * POST /api/chat
 * 调用 Dify 进行对话
 *
 * 请求体:
 * {
 *   "toolId": 1,               // 工具 ID（用于定位 prompt 配置）
 *   "message": "用户输入",
 *   "conversationId": "可选"    // 会话 ID（用于多轮对话上下文）
 * }
 *
 * 流式响应（SSE），返回 Dify 的 answer 片段
 */

import { NextRequest, NextResponse } from "next/server";
import { sendChatMessage } from "@/lib/dify";
import { TOOLS } from "@/data/tools";

export const runtime = "edge"; // 使用 Edge Runtime 支持流式响应

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { toolId, message, conversationId } = body;

    if (!toolId || !message) {
      return NextResponse.json(
        { error: "缺少 toolId 或 message" },
        { status: 400 }
      );
    }

    const tool = TOOLS.find((t) => t.id === Number(toolId));
    if (!tool) {
      return NextResponse.json(
        { error: `未找到 ID 为 ${toolId} 的工具` },
        { status: 404 }
      );
    }

    // 构建 Dify 输入变量（inputs）
    const inputs: Record<string, string> = {
      tool_name: tool.name,
      tool_desc: tool.desc,
      ...(tool.systemPrompt && { system_override: tool.systemPrompt }),
    };

    // 创建流式响应
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      async start(controller) {
        try {
          await sendChatMessage(
            {
              query: message,
              userId: `toolbox-user-${toolId}`,
              conversationId: conversationId ?? undefined,
              stream: true,
              inputs,
            },
            // onChunk: 每次收到文本片段
            (text) => {
              controller.enqueue(
                encoder.encode(`data: ${JSON.stringify({ type: "chunk", text })}\n\n`)
              );
            },
            // onEnd: 完成
            (fullAnswer) => {
              controller.enqueue(
                encoder.encode(
                  `data: ${JSON.stringify({ type: "done", answer: fullAnswer })}\n\n`
                )
              );
              controller.close();
            },
            // onError
            (err) => {
              controller.enqueue(
                encoder.encode(
                  `data: ${JSON.stringify({ type: "error", message: err.message })}\n\n`
                )
              );
              controller.close();
            }
          );
        } catch {
          controller.close();
        }
      },
    });

    return new Response(stream, {
      headers: {
        "Content-Type": "text/event-stream; charset=utf-8",
        "Cache-Control": "no-cache, no-transform",
        Connection: "keep-alive",
        "X-Accel-Buffering": "no", // 防止 Nginx 缓冲
      },
    });
  } catch (err) {
    const error = err instanceof Error ? err.message : "服务器内部错误";
    return NextResponse.json({ error }, { status: 500 });
  }
}
