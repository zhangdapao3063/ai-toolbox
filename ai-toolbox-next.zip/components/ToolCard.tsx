"use client";

import type { Tool } from "@/types";

interface ToolCardProps {
  tool: Tool;
  onOpen: (tool: Tool) => void;
  staggerIndex?: number;
}

export default function ToolCard({ tool, onOpen, staggerIndex = 0 }: ToolCardProps) {
  const tagColorMap = {
    hot: "bg-red-500/10 text-red-400 border-red-500/20",
    new: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
    pro:  "bg-amber-500/10 text-amber-400 border-amber-500/20",
  };

  const staggerClass = `stagger-${Math.min((staggerIndex % 16) + 1, 16)}`;

  return (
    <article
      className={`
        relative overflow-hidden rounded-2xl border border-white/8
        bg-white/4 backdrop-blur-2xl
        hover:border-indigo-500/40 hover:bg-white/6
        hover:-translate-y-1.5 hover:shadow-glow
        transition-all duration-300 cursor-pointer group
        opacity-0 animate-card-reveal ${staggerClass}
      `}
      style={{ "--card-accent": tool.accent, "--icon-bg": tool.iconBg } as React.CSSProperties}
      onClick={() => onOpen(tool)}
    >
      {/* 顶部渐变光效 */}
      <div
        className="absolute top-0 left-0 right-0 h-[2.5px] opacity-0 group-hover:opacity-100 transition-opacity duration-300"
        style={{ background: tool.accent }}
      />

      <div className="p-6">
        {/* 头部：图标 + 名称 */}
        <div className="flex items-start gap-4 mb-4">
          <div
            className="flex-shrink-0 w-12 h-12 rounded-xl flex items-center justify-center text-2xl
                       group-hover:scale-110 group-hover:-rotate-3 transition-transform duration-300"
            style={{ background: tool.iconBg }}
          >
            {tool.icon}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-[16.5px] font-bold text-slate-100 mb-1 leading-tight">
              {tool.name}
            </h3>
            {tool.tag && (
              <span className={`inline-flex px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${tagColorMap[tool.tag]}`}>
                {tool.tagText}
              </span>
            )}
          </div>
        </div>

        {/* 描述 */}
        <p className="text-[13.5px] text-slate-400 leading-relaxed mb-4 line-clamp-2">
          {tool.desc}
        </p>

        {/* 底部：模型标签 + 按钮 */}
        <div className="flex items-center justify-between">
          <div className="flex flex-wrap gap-1.5">
            {tool.models.slice(0, 3).map((m) => (
              <span
                key={m}
                className="px-2 py-1 rounded-md text-[11px] font-semibold
                           bg-indigo-500/8 text-indigo-400 border border-indigo-500/15"
              >
                {m}
              </span>
            ))}
          </div>
          <button
            className="ml-3 flex-shrink-0 px-4 py-2 rounded-lg text-[13px] font-bold
                       text-white bg-gradient-to-r from-indigo-500 to-purple-500
                       hover:shadow-glow-sm hover:-translate-y-0.5
                       transition-all duration-150"
            onClick={(e) => { e.stopPropagation(); onOpen(tool); }}
          >
            使用 →
          </button>
        </div>
      </div>
    </article>
  );
}
