/**
 * GET /api/tools
 * 返回工具列表，支持分类过滤和搜索
 *
 * 示例:
 *   GET /api/tools                     → 全部工具
 *   GET /api/tools?category=writing    → 核心写作类
 *   GET /api/tools?q=书名              → 搜索"书名"相关工具
 */

import { NextRequest, NextResponse } from "next/server";
import { TOOLS, CATEGORIES } from "@/data/tools";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const category = searchParams.get("category") ?? "all";
  const q = searchParams.get("q") ?? "";

  // 合并分类计数
  const categoryWithCount = CATEGORIES.map((cat) => ({
    ...cat,
    count: cat.id === "all" ? TOOLS.length : TOOLS.filter((t) => t.category === cat.id).length,
  }));

  let tools = TOOLS;

  if (category !== "all") {
    tools = tools.filter((t) => t.category === category);
  }

  if (q.trim()) {
    const query = q.trim().toLowerCase();
    tools = tools.filter(
      (t) =>
        t.name.toLowerCase().includes(query) ||
        t.desc.toLowerCase().includes(query)
    );
  }

  return NextResponse.json({
    tools,
    categories: categoryWithCount,
    total: tools.length,
  });
}
