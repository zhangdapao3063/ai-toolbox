"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import type { Tool, CategoryDef } from "@/types";

interface ToolModalProps {
  tool: Tool | null;
  categories: CategoryDef[];
  onClose: () => void;
}

// ================================================================
// 消息类型
// ================================================================
interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  isStreaming?: boolean;
}

// ================================================================
// 工具详情弹窗（含 AI 对话）
// ================================================================
export default function ToolModal({ tool, categories, onClose }: ToolModalProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [conversationId, setConversationId] = useState<string | null>(null);

  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // 关闭时重置状态
  useEffect(() => {
    if (!tool) return;
    setMessages([]);
    setInput("");
    setIsLoading(false);
    setError(null);
    setConversationId(null);
  }, [tool]);

  // 自动滚动到底部
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // ESC 关闭
  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [onClose]);

  if (!tool) return null;

  const categoryLabel = categories.find((c) => c.id === tool.category)?.label ?? "";

  // ================================================================
  // 发送消息（调用 /api/chat SSE）
  // ================================================================
  const handleSend = useCallback(async () => {
    const trimmed = input.trim();
    if (!trimmed || isLoading) return;

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      role: "user",
      content: trimmed,
    };

    const assistantMsg: Message = {
      id: `asst-${Date.now()}`,
      role: "assistant",
      content: "",
      isStreaming: true,
    };

    setMessages((prev) => [...prev, userMsg, assistantMsg]);
    setInput("");
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          toolId: tool.id,
          message: trimmed,
          conversationId,
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error ?? "请求失败");
      }

      // 解析 SSE 流
      const reader = response.body?.getReader();
      const decoder = new TextDecoder("utf-8");
      let buffer = "";

      if (!reader) throw new Error("无法读取响应流");

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";

        for (const line of lines) {
          const trimmed2 = line.trim();
          if (!trimmed2 || !trimmed2.startsWith("data:")) continue;

          const dataStr = trimmed2.slice(5).trim();
          if (!dataStr) continue;

          try {
            const event = JSON.parse(dataStr);

            if (event.type === "chunk") {
              setMessages((prev) =>
                prev.map((m) =>
                  m.id === assistantMsg.id
                    ? { ...m, content: m.content + event.text }
                    : m
                )
              );
            }

            if (event.type === "done") {
              setConversationId(event.conversationId ?? null);
              setMessages((prev) =>
                prev.map((m) =>
                  m.id === assistantMsg.id ? { ...m, isStreaming: false } : m
                )
              );
            }

            if (event.type === "error") {
              throw new Error(event.message);
            }
          } catch {
            // 忽略解析错误
          }
        }
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "未知错误";
      setError(msg);
      setMessages((prev) =>
        prev.map((m) =>
          m.id === assistantMsg.id ? { ...m, isStreaming: false } : m
        )
      );
    } finally {
      setIsLoading(false);
    }
  }, [input, isLoading, tool.id, conversationId]);

  // 回车发送（Shift+回车 换行）
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // 复制结果
  const copyResult = () => {
    const lastAssistant = [...messages].reverse().find((m) => m.role === "assistant");
    if (lastAssistant) {
      navigator.clipboard.writeText(lastAssistant.content);
    }
  };

  return (
    <>
      {/* 遮罩 */}
      <div
        className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm
                   opacity-0 animate-in fade-in duration-200"
        onClick={onClose}
      />

      {/* 弹窗主体 */}
      <div
        className="fixed inset-x-4 bottom-4 top-16 z-50 mx-auto
                   max-w-2xl w-full max-h-[calc(100vh-8rem)]
                   rounded-2xl border border-white/10
                   bg-[#111827] dark:bg-[#111827]
                   shadow-2xl flex flex-col overflow-hidden
                   translate-y-4 opacity-0 animate-in slide-in-from-bottom-4 duration-300"
        role="dialog"
        aria-modal="true"
      >
        {/* ── 头部 ─────────────────────────────────────────── */}
        <header className="flex items-center gap-4 px-6 py-5 border-b border-white/8 flex-shrink-0">
          <div
            className="w-14 h-14 rounded-xl flex items-center justify-center text-[28px] flex-shrink-0"
            style={{ background: tool.iconBg }}
          >
            {tool.icon}
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="text-[22px] font-extrabold text-slate-100 leading-tight truncate">
              {tool.name}
            </h2>
            <p className="text-[12px] text-slate-500">{categoryLabel}</p>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-lg flex items-center justify-center
                       text-slate-500 hover:text-red-400 hover:bg-red-500/10
                       hover:border hover:border-red-500/30 border border-transparent
                       transition-all duration-150 flex-shrink-0 text-[17px]"
          >
            ✕
          </button>
        </header>

        {/* ── 功能介绍（非对话模式，初始显示）─────────────── */}
        {messages.length === 0 && (
          <div className="px-6 py-5 flex-shrink-0">
            <p className="text-[14px] text-slate-400 leading-relaxed mb-4">
              {tool.detailDesc}
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-4">
              {tool.features.map((f, i) => (
                <div key={i} className="flex items-start gap-2 text-[13px] text-slate-300">
                  <span className="text-emerald-400 mt-0.5 flex-shrink-0">✓</span>
                  {f}
                </div>
              ))}
            </div>
            <div className="flex flex-wrap gap-1.5">
              {tool.models.map((m) => (
                <span
                  key={m}
                  className="px-3 py-1 rounded-md text-[12px] font-semibold
                             bg-indigo-500/10 text-indigo-400 border border-indigo-500/20"
                >
                  🤖 {m}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* ── 对话历史区域 ────────────────────────────────── */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 min-h-0">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`
                  max-w-[85%] px-4 py-3 rounded-2xl text-[14px] leading-relaxed
                  ${msg.role === "user"
                    ? "bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-br-md"
                    : "bg-white/6 text-slate-200 rounded-bl-md border border-white/6"
                  }
                `}
              >
                {msg.content}
                {msg.isStreaming && (
                  <span className="ml-1 inline-block w-1.5 h-4 bg-indigo-400 rounded-sm animate-pulse" />
                )}
              </div>
            </div>
          ))}

          {error && (
            <div className="flex justify-start">
              <div className="max-w-[85%] px-4 py-3 rounded-2xl rounded-bl-md
                              bg-red-500/10 border border-red-500/20 text-red-400 text-[13px]">
                ⚠️ {error}
              </div>
            </div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* ── 输入区 ──────────────────────────────────────── */}
        <div className="flex-shrink-0 px-4 py-4 border-t border-white/8">
          {messages.length > 0 && (
            <div className="flex gap-2 mb-3">
              <button
                onClick={copyResult}
                className="px-3 py-1.5 rounded-lg text-[12px] font-semibold
                           bg-white/5 text-slate-400 hover:text-slate-200 hover:bg-white/10
                           border border-white/8 transition-all duration-150"
              >
                📋 复制结果
              </button>
              <button
                onClick={() => { setMessages([]); setConversationId(null); }}
                className="px-3 py-1.5 rounded-lg text-[12px] font-semibold
                           bg-white/5 text-slate-400 hover:text-slate-200 hover:bg-white/10
                           border border-white/8 transition-all duration-150"
              >
                🗑️ 清空对话
              </button>
            </div>
          )}

          <div className="flex gap-3 items-end">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={`输入内容使用「${tool.name}」...`}
              rows={1}
              className="
                flex-1 px-4 py-3 rounded-xl resize-none max-h-40
                bg-white/5 border border-white/8 text-slate-100 text-[14px]
                placeholder-slate-600 outline-none
                focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/20
                transition-all duration-200
              "
              style={{ height: "auto", overflow: "hidden" }}
              onInput={(e) => {
                const el = e.currentTarget;
                el.style.height = "auto";
                el.style.height = Math.min(el.scrollHeight, 160) + "px";
              }}
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className={`
                flex-shrink-0 w-11 h-11 rounded-xl flex items-center justify-center
                text-[18px] transition-all duration-150
                ${input.trim() && !isLoading
                  ? "bg-gradient-to-br from-indigo-500 to-purple-500 text-white hover:shadow-glow hover:-translate-y-0.5"
                  : "bg-white/5 text-slate-600 cursor-not-allowed"
                }
              `}
            >
              {isLoading ? "⏳" : "↑"}
            </button>
          </div>
          <p className="text-[11px] text-slate-600 mt-2 text-center">
            按 Enter 发送 · Shift + Enter 换行
          </p>
        </div>
      </div>
    </>
  );
}
