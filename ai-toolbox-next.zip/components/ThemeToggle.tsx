"use client";

import { useEffect, useState } from "react";

export default function ThemeToggle() {
  const [isDark, setIsDark] = useState(true);

  useEffect(() => {
    // 读取本地存储或跟随系统
    const stored = localStorage.getItem("theme");
    if (stored === "light") {
      setIsDark(false);
      document.documentElement.classList.remove("dark");
      document.documentElement.classList.add("light");
    } else {
      setIsDark(true);
      document.documentElement.classList.add("dark");
      document.documentElement.classList.remove("light");
    }
  }, []);

  const toggle = () => {
    const next = !isDark;
    setIsDark(next);
    localStorage.setItem("theme", next ? "dark" : "light");
    if (next) {
      document.documentElement.classList.add("dark");
      document.documentElement.classList.remove("light");
    } else {
      document.documentElement.classList.remove("dark");
      document.documentElement.classList.add("light");
    }
  };

  return (
    <button
      onClick={toggle}
      title={isDark ? "切换到亮色模式" : "切换到暗色模式"}
      className="
        w-10 h-10 rounded-xl border border-white/8 bg-white/4
        text-slate-400 hover:text-slate-100 hover:border-indigo-500/40 hover:bg-white/6
        flex items-center justify-center text-[18px]
        transition-all duration-150 hover:rotate-12
      "
    >
      {isDark ? "🌙" : "☀️"}
    </button>
  );
}
