"use client";

import { useState, useEffect, useCallback } from "react";
import type { Tool, CategoryDef } from "@/types";
import ToolCard from "@/components/ToolCard";
import FilterTabs from "@/components/FilterTabs";
import SearchBar from "@/components/SearchBar";
import ToolModal from "@/components/ToolModal";
import ThemeToggle from "@/components/ThemeToggle";

// ================================================================
// 首页 —— 工具箱主视图
// ================================================================
export default function HomePage() {
  const [tools, setTools] = useState<Tool[]>([]);
  const [categories, setCategories] = useState<CategoryDef[]>([]);
  const [activeCategory, setActiveCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTool, setSelectedTool] = useState<Tool | null>(null);
  const [loading, setLoading] = useState(true);

  // 拉取工具数据
  const fetchTools = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (activeCategory !== "all") params.set("category", activeCategory);
      if (searchQuery) params.set("q", searchQuery);

      const res = await fetch(`/api/tools?${params.toString()}`);
      if (!res.ok) throw new Error("获取工具列表失败");
      const data = await res.json();

      setTools(data.tools);
      if (data.categories) setCategories(data.categories);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [activeCategory, searchQuery]);

  // 初次加载
  useEffect(() => {
    fetchTools();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // 防抖搜索
  useEffect(() => {
    const timer = setTimeout(fetchTools, 300);
    return () => clearTimeout(timer);
  }, [fetchTools]);

  const handleCategoryChange = (id: string) => {
    setActiveCategory(id);
    setSearchQuery("");
  };

  const handleSearch = (q: string) => {
    setSearchQuery(q);
    if (q) setActiveCategory("all");
  };

  return (
    <>
      {/* 导航栏 */}
      <nav className="sticky top-0 z-40 h-[68px] px-8 flex items-center justify-between
                      backdrop-blur-2xl border-b border-white/8 bg-[#0a0e1a]/80">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-500
                          flex items-center justify-center text-lg font-bold text-white shadow-glow">
            ✦
          </div>
          <span className="text-[18px] font-extrabold bg-gradient-to-r from-indigo-400 to-purple-400
                           bg-clip-text text-transparent tracking-tight">
            AI 创作工具箱
          </span>
        </div>
        <ThemeToggle />
      </nav>

      {/* 主内容 */}
      <main className="max-w-6xl mx-auto px-7 py-12 pb-24">

        {/* Hero */}
        <section className="text-center mb-14 animate-fade-slide-down">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full
                          bg-indigo-500/10 border border-indigo-500/20 text-indigo-400
                          text-[13px] font-semibold mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse-slow" />
            全链路 AI 创作平台
          </div>
          <h1 className="text-[clamp(30px,5vw,48px)] font-extrabold leading-tight mb-4 tracking-tight">
            智能创作<br />
            <span className="bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400
                             bg-clip-text text-transparent">
              一站式工具箱
            </span>
          </h1>
          <p className="text-[16px] text-slate-400 max-w-lg mx-auto mb-8">
            从灵感到成品，覆盖小说、短剧、公众号、视频等全场景创作的 16+ AI 工具，
            对接全球顶尖大模型
          </p>
          <div className="flex justify-center gap-10 flex-wrap">
            {[
              { num: "16+", label: "创作工具" },
              { num: "9",   label: "大模型"   },
              { num: "6",   label: "功能分类" },
            ].map(({ num, label }) => (
              <div key={label} className="text-center">
                <div className="text-[28px] font-extrabold text-slate-100">{num}</div>
                <div className="text-[12px] text-slate-500 mt-0.5">{label}</div>
              </div>
            ))}
          </div>
        </section>

        {/* 搜索 + 分类 */}
        <section className="mb-9 flex flex-col gap-4">
          <SearchBar value={searchQuery} onChange={handleSearch} />
          {categories.length > 0 && (
            <FilterTabs
              categories={categories}
              active={activeCategory}
              onChange={handleCategoryChange}
            />
          )}
        </section>

        {/* 工具卡片网格 */}
        <section>
          {loading ? (
            /* Loading Skeleton */
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {Array.from({ length: 9 }).map((_, i) => (
                <div
                  key={i}
                  className="h-44 rounded-2xl bg-white/4 border border-white/8 animate-pulse"
                />
              ))}
            </div>
          ) : tools.length === 0 ? (
            /* 空状态 */
            <div className="text-center py-24 text-slate-500">
              <div className="text-5xl mb-4 opacity-40">🔍</div>
              <p className="text-[15px] font-medium">没有找到匹配的工具，换个关键词试试？</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {tools.map((tool, i) => (
                <ToolCard
                  key={tool.id}
                  tool={tool}
                  staggerIndex={i}
                  onOpen={setSelectedTool}
                />
              ))}
            </div>
          )}
        </section>
      </main>

      {/* 页脚 */}
      <footer className="text-center py-10 text-slate-600 text-[12px] border-t border-white/5">
        AI 创作工具箱 — 让创作更高效 · 更智能 · 更自由
      </footer>

      {/* 工具详情弹窗 */}
      <ToolModal
        tool={selectedTool}
        categories={categories}
        onClose={() => setSelectedTool(null)}
      />
    </>
  );
}
