// ================================================================
// 工具数据 —— 对应 Dify 中的 App / Workflow
// ================================================================

import type { CategoryDef, Tool } from "@/types";

export const CATEGORIES: CategoryDef[] = [
  { id: "all",       label: "全部",         icon: "⚡" },
  { id: "writing",   label: "核心写作",     icon: "✍️" },
  { id: "planning",  label: "构思规划",     icon: "💡" },
  { id: "character", label: "人设世界观",   icon: "🎭" },
  { id: "package",   label: "包装推广",     icon: "📦" },
  { id: "video",     label: "剧本视频",     icon: "🎬" },
];

export const TOOLS: Tool[] = [
  // ── 核心写作 ──────────────────────────────────────────────────
  {
    id: 1,
    category: "writing",
    icon: "✍️",
    name: "AI 写作",
    tag: "hot",
    tagText: "热门",
    desc: "一句话生成 2000 字以上正文，支持长篇小说、短篇小说、公众号文章、剧本等多种文体",
    detailDesc: "基于多轮对话上下文理解，一键生成长篇正文。内置多种写作风格模板，可自定义输出长度和文风，是整个创作流程的核心引擎。",
    models: ["GPT-4o", "Claude", "DeepSeek"],
    features: [
      "一句话指令即可生成 2000~5000 字正文",
      "支持长篇小说 / 短篇小说 / 公众号 / 剧本等多种体裁",
      "自动保持上下文连贯性，续写不跑偏",
      "内置爆款写作模板与行业风格库",
    ],
    accent: "linear-gradient(135deg, #6366f1, #8b5cf6)",
    iconBg: "linear-gradient(135deg, rgba(99,102,241,0.15), rgba(139,92,246,0.1))",
  },
  {
    id: 2,
    category: "writing",
    icon: "✨",
    name: "AI 扩写润色",
    tag: null,
    tagText: "",
    desc: "一键扩写现有情节、润色文笔、优化对话，让内容更加生动饱满",
    detailDesc: "对已有文本进行深度扩写与润色处理。通过 AI 理解上下文语义，在保留原意基础上丰富细节描写、优化语言表达。",
    models: ["GPT-4o", "Claude"],
    features: [
      "智能识别扩写位置，精准插入细节描写",
      "对话润色：让角色说话更有个性",
      "去 AI 味处理，文字自然流畅",
      "支持批量段落处理",
    ],
    accent: "linear-gradient(135deg, #06b6d4, #0ea5e9)",
    iconBg: "linear-gradient(135deg, rgba(6,182,212,0.15), rgba(14,165,233,0.1))",
  },
  {
    id: 3,
    category: "writing",
    icon: "📝",
    name: "AI 续写正文",
    tag: "new",
    tagText: "升级",
    desc: "关联上文剧情后自动理解上下文，根据大纲思路智能续写下一章节",
    detailDesc: "强大的上下文关联能力，自动分析前文剧情走向、人物性格、叙事节奏，确保续写内容与前文无缝衔接。",
    models: ["Claude", "GPT-4o", "DeepSeek"],
    features: [
      "最长支持 50 万字级超长文本上下文",
      "自动记忆前文人物关系与伏笔",
      "根据大纲节点精准推进剧情",
      "支持多分支剧情选择续写方向",
    ],
    accent: "linear-gradient(135deg, #8b5cf6, #a78bfa)",
    iconBg: "linear-gradient(135deg, rgba(139,92,246,0.15), rgba(167,139,250,0.1))",
  },

  // ── 构思规划 ──────────────────────────────────────────────────
  {
    id: 4,
    category: "planning",
    icon: "💡",
    name: "AI 生成脑洞",
    tag: "pro",
    tagText: "推荐",
    desc: "将零散的想法快速拓展为成熟的故事框架，激发无限创作灵感",
    detailDesc: "输入任意关键词、灵感碎片或模糊想法，AI 将其扩展为完整的故事框架，包含冲突设计、高潮布局、反转设置等。",
    models: ["GPT-4o", "Claude", "Kimi"],
    features: [
      "关键词 → 故事框架 一键转换",
      "自动设计冲突点和高潮节奏",
      "提供多个脑洞方案供选择",
      "支持融合多个创意方向",
    ],
    accent: "linear-gradient(135deg, #f59e0b, #f97316)",
    iconBg: "linear-gradient(135deg, rgba(245,158,11,0.15), rgba(249,115,22,0.1))",
  },
  {
    id: 5,
    category: "planning",
    icon: "📋",
    name: "AI 生成大纲",
    tag: null,
    tagText: "",
    desc: "梳理完善作品脉络，快速生成结构清晰的作品大纲，规划全书走向",
    detailDesc: "根据故事类型、目标字数、读者群体等信息，自动生成包含卷章划分、主线副线、关键转折点的完整作品大纲。",
    models: ["GPT-4o", "DeepSeek", "千问"],
    features: [
      "自动拆分卷章结构，合理分配篇幅",
      "主副线交织设计，层次分明",
      "关键转折点与伏笔标注",
      "支持番茄 / 起点等平台结构规范",
    ],
    accent: "linear-gradient(135deg, #10b981, #059669)",
    iconBg: "linear-gradient(135deg, rgba(16,185,129,0.15), rgba(5,150,105,0.1))",
  },
  {
    id: 6,
    category: "planning",
    icon: "📑",
    name: "AI 生成细纲",
    tag: null,
    tagText: "",
    desc: "结合番茄爆款公式将大纲拆分为条理分明的细纲，每章都有明确任务",
    detailDesc: "在大纲基础上进一步细化到每一章的具体内容安排，结合平台爆款公式确保每章都有吸引读者的钩子。",
    models: ["GPT-4o", "Claude"],
    features: [
      "按章细化，明确每章核心任务",
      "融入番茄 / 七猫等平台爆款公式",
      "自动设置章末悬念钩子",
      "爆点分布均匀，避免节奏拖沓",
    ],
    accent: "linear-gradient(135deg, #ec4899, #db2777)",
    iconBg: "linear-gradient(135deg, rgba(236,72,153,0.15), rgba(219,39,119,0.1))",
  },

  // ── 人设世界观 ────────────────────────────────────────────────
  {
    id: 7,
    category: "character",
    icon: "🎭",
    name: "AI 生成人设",
    tag: "hot",
    tagText: "热门",
    desc: "快速生成富有代入感的人物设定，包括外貌、性格、背景、成长弧光",
    detailDesc: "创建立体丰满的角色档案，涵盖外貌特征、性格缺陷、成长动机、人际关系网等全方位人设信息。",
    models: ["Claude", "GPT-4o"],
    features: [
      "完整角色档案：外貌 / 性格 / 背景 / 动机",
      "角色成长弧光设计，有血有肉",
      "自动生成角色之间的人物关系图",
      "避免模板化人设，保证独特性",
    ],
    accent: "linear-gradient(135deg, #8b5cf6, #6366f1)",
    iconBg: "linear-gradient(135deg, rgba(139,92,246,0.15), rgba(99,102,241,0.1))",
  },
  {
    id: 8,
    category: "character",
    icon: "🌍",
    name: "AI 世界观设定",
    tag: null,
    tagText: "",
    desc: "构建符合作品需求的完整世界观，包括力量体系、社会结构、地理环境",
    detailDesc: "针对玄幻 / 科幻 / 都市 / 历史等不同题材，自动生成自洽的世界观体系，确保设定无逻辑矛盾。",
    models: ["GPT-4o", "Claude", "Kimi"],
    features: [
      "力量等级体系自动构建",
      "社会结构 / 阶层 / 组织设计",
      "地理地图与区域特色描述",
      "设定自洽性检测，发现矛盾自动提示",
    ],
    accent: "linear-gradient(135deg, #0ea5e9, #06b6d4)",
    iconBg: "linear-gradient(135deg, rgba(14,165,233,0.15), rgba(6,182,212,0.1))",
  },
  {
    id: 9,
    category: "character",
    icon: "⚡",
    name: "AI 生成金手指",
    tag: "new",
    tagText: "新",
    desc: "生成富有创意且具备成长性的小说金手指设定，增强爽感体验",
    detailDesc: "围绕主角身份和题材特点，设计具有独特性、成长空间和爽感的金手指系统，避免千篇一律的套路化设定。",
    models: ["GPT-4o", "DeepSeek"],
    features: [
      "多类型金手指：系统 / 物品 / 血脉 / 天赋",
      "成长路径设计，随剧情逐步解锁能力",
      "代价机制设计，增加戏剧张力",
      "与世界观高度融合，不突兀",
    ],
    accent: "linear-gradient(135deg, #f59e0b, #eab308)",
    iconBg: "linear-gradient(135deg, rgba(245,158,11,0.15), rgba(234,179,8,0.1))",
  },
  {
    id: 10,
    category: "character",
    icon: "🏷️",
    name: "AI 生成名字",
    tag: null,
    tagText: "",
    desc: "批量生成人名、地名、功法名、武器名等命名素材，解决取名难题",
    detailDesc: "根据作品题材风格批量生成各类命名素材，名字自带气质属性，符合角色定位和世界观设定。",
    models: ["GPT-4o", "千问"],
    features: [
      "人名 / 地名 / 功法 / 武器 / 宗门等多类别",
      "古风 / 仙侠 / 都市 / 西幻等风格适配",
      "一键生成 20 个备选方案",
      "名字附带寓意解析",
    ],
    accent: "linear-gradient(135deg, #64748b, #94a3b8)",
    iconBg: "linear-gradient(135deg, rgba(100,116,139,0.15), rgba(148,163,184,0.1))",
  },

  // ── 包装推广 ──────────────────────────────────────────────────
  {
    id: 11,
    category: "package",
    icon: "📖",
    name: "AI 生成书名",
    tag: null,
    tagText: "",
    desc: "结合最新爆款趋势，生成最具竞争力的吸睛作品名称",
    detailDesc: "分析当前各平台热门书名的命名规律，结合你的作品类型和大纲，生成高点击率的书名候选方案。",
    models: ["GPT-4o", "DeepSeek"],
    features: [
      "实时分析各平台热门书名趋势",
      "SEO 优化，提升搜索曝光率",
      "多风格：直白型 / 悬念型 / 反差型",
      "每个书名附带推荐理由",
    ],
    accent: "linear-gradient(135deg, #ef4444, #dc2626)",
    iconBg: "linear-gradient(135deg, rgba(239,68,68,0.15), rgba(220,38,38,0.1))",
  },
  {
    id: 12,
    category: "package",
    icon: "📢",
    name: "AI 生成简介",
    tag: "pro",
    tagText: "必备",
    desc: "根据书名和大纲快速生成能引发读者兴趣的爆款简介文案",
    detailDesc: "提炼作品最吸引人的核心卖点，生成符合各平台简介规范的引流文案，最大化点击转化率。",
    models: ["GPT-4o", "Claude"],
    features: [
      "黄金三段式简介结构",
      "突出核心卖点和独特看点",
      "悬念钩子设计，引发阅读欲望",
      "自动适配不同平台简介字数限制",
    ],
    accent: "linear-gradient(135deg, #f43f5e, #e11d48)",
    iconBg: "linear-gradient(135deg, rgba(244,63,94,0.15), rgba(225,29,72,0.1))",
  },
  {
    id: 13,
    category: "package",
    icon: "🌟",
    name: "AI 黄金开篇",
    tag: "hot",
    tagText: "爆款",
    desc: "学习番茄、起点等平台爆款开篇风格，自动生成黄金前三章",
    detailDesc: "深度分析头部平台的爆款开篇规律——黄金三章法则，为你量身打造高留存率的开篇章节。",
    models: ["GPT-4o", "Claude", "DeepSeek"],
    features: [
      "黄金三章法则深度应用",
      "首章即高潮，三行内出冲突",
      "代入感极强的开篇切入方式",
      "针对不同平台的调优策略",
    ],
    accent: "linear-gradient(135deg, #f59e0b, #ef4444)",
    iconBg: "linear-gradient(135deg, rgba(245,158,11,0.15), rgba(239,68,68,0.1))",
  },
  {
    id: 14,
    category: "package",
    icon: "🔍",
    name: "AI 拆书",
    tag: "new",
    tagText: "新",
    desc: "一键分析书籍的核心要素：世界观、人设、大纲、金手指、吸引点",
    detailDesc: "上传书籍内容后，AI 自动拆解其世界设定、主角人设、剧情大纲、金手指设计等核心要素，供参考借鉴。",
    models: ["Claude", "GPT-4o", "Kimi"],
    features: [
      "全自动拆解书籍核心要素",
      "输出结构化的分析报告",
      "识别成功作品的底层规律",
      "支持导出拆书报告用于团队学习",
    ],
    accent: "linear-gradient(135deg, #14b8a6, #0d9488)",
    iconBg: "linear-gradient(135deg, rgba(20,184,166,0.15), rgba(13,148,136,0.1))",
  },

  // ── 剧本视频 ──────────────────────────────────────────────────
  {
    id: 15,
    category: "video",
    icon: "🎬",
    name: "AI 生成剧本",
    tag: null,
    tagText: "",
    desc: "将文章内容转化为短剧剧本或短视频分镜脚本",
    detailDesc: "智能提取文章中的关键情节和对话，转换为标准格式短剧剧本或短视频拍摄分镜脚本。",
    models: ["GPT-4o", "Claude"],
    features: [
      "短剧剧本 / 短视频脚本双模式",
      "自动提取对话与动作描述",
      "分镜画面建议与时长估算",
      "支持导出专业格式剧本文件",
    ],
    accent: "linear-gradient(135deg, #a855f7, #7c3aed)",
    iconBg: "linear-gradient(135deg, rgba(168,85,247,0.15), rgba(124,58,237,0.1))",
  },
  {
    id: 16,
    category: "video",
    icon: "🎥",
    name: "AI 视频提示词",
    tag: "pro",
    tagText: "进阶",
    desc: "将剧情转化为 AI 视频大模型能理解的专业导演视角提示词",
    detailDesc: "将文字剧情转化为 Sora、Runway、即梦等 AI 视频模型可用的专业提示词，包含画面描述、镜头运动、光影氛围等参数。",
    models: ["GPT-4o", "Claude", "Gemini"],
    features: [
      "导演级提示词自动生成",
      "支持 Sora-2 / Veo / Runway / 即梦",
      "包含镜头运动 / 光影 / 构图参数",
      "一键复制直接使用于视频平台",
    ],
    accent: "linear-gradient(135deg, #3b82f6, #2563eb)",
    iconBg: "linear-gradient(135deg, rgba(59,130,246,0.15), rgba(37,99,235,0.1))",
  },
];

/** 根据分类过滤工具 */
export function getToolsByCategory(category: string): Tool[] {
  if (category === "all") return TOOLS;
  return TOOLS.filter((t) => t.category === category);
}

/** 搜索工具 */
export function searchTools(query: string): Tool[] {
  const q = query.toLowerCase().trim();
  if (!q) return TOOLS;
  return TOOLS.filter(
    (t) =>
      t.name.toLowerCase().includes(q) ||
      t.desc.toLowerCase().includes(q)
  );
}
